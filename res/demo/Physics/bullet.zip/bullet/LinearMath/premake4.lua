	project "LinearMath"

	kind "StaticLib"
	includedirs {
		"..",
	}
	files {
		"*.cpp",
		"*.h"
	}
